# Jadwal AN-NAWA — Proyek Android

Proyek Android native sederhana berbasis Java yang menampilkan Google Apps Script Jadwal Pelajaran AN-NAWA melalui Android WebView.

## Isi proyek
- `settings.gradle` dan `build.gradle` di root proyek
- `app/build.gradle` menggunakan Java 17; tidak memakai Kotlin
- `MainActivity.java` memuat URL Apps Script yang ditentukan
- `AndroidManifest.xml` berisi izin internet

## Build
Proyek ini dapat dibangun menggunakan Gradle 8.9, JDK 17, Android SDK Platform 35 dan Build Tools 35.0.0.

URL jadwal yang digunakan:
`https://script.google.com/macros/s/AKfycbw9Qp8aq7DkUg7Fl6lEgwklJV611qMLLWnz7innmCrTsGVKirPjxyyYfs6qIXOm49hQ/exec`
