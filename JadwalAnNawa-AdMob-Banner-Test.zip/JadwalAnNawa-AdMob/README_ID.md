# Jadwal AN-NAWA — proyek Android dengan banner AdMob (uji coba)

Proyek ini mempertahankan aplikasi WebView jadwal yang sudah ada dan menambahkan banner kecil di bagian bawah.

## Penting
- Build ini menggunakan **ID unit banner uji resmi Google** (`ca-app-pub-3940256099942544/9214589741`) agar pengujian tidak menghasilkan klik iklan produksi yang tidak disengaja.
- ID aplikasi AdMob milik Anda sudah dimasukkan ke `AndroidManifest.xml`.
- Jangan klik iklan uji untuk mencari penghasilan. Iklan uji hanya untuk pemeriksaan teknis.
- Setelah integrasi diuji dan aplikasi memenuhi syarat/persetujuan AdMob, ganti `TEST_BANNER_ID` di `MainActivity.java` dengan ID unit banner produksi Anda: `ca-app-pub-3143680001009952/2037930346`.
- Penayangan iklan produksi tetap bergantung pada penyiapan pembayaran, penautan toko aplikasi yang didukung, dan persetujuan AdMob. Banner tidak menjamin semua materi iklan selalu berupa teks statis; kode ini tidak menambahkan format interstitial atau rewarded.

## Build melalui GitHub Actions
Unggah isi folder proyek ini ke root repositori (bukan mengunggah ZIP sebagai satu file), pastikan workflow berada di `.github/workflows/build-apk.yml`, lalu buka tab Actions dan jalankan workflow. APK debug akan tersedia sebagai artifact setelah build berhasil.
