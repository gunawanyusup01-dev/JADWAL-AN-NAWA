package id.annawa.jadwal;

import android.app.DownloadManager;
import android.net.Uri;
import android.os.Environment;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;

public class MainActivity extends Activity {

    private static final String APP_URL =
        "https://script.google.com/macros/s/AKfycbzDob9LtQqXWowhvh2nZg_kH5m3euc5-PslwRQPcbjpBtyukV7J2dtVHXEPeLLJUOhL/exec";

    private static final String BANNER_ID =
        "ca-app-pub-3143680001009952/2037930346";

    private WebView webView;
    private LinearLayout errorPanel;
    private AdView adView;
    private TextView adStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(Color.rgb(18, 83, 53));
        getWindow().setNavigationBarColor(Color.BLACK);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        // Inisialisasi panel error terlebih dahulu agar siap dipakai
        errorPanel = new LinearLayout(this);
        errorPanel.setOrientation(LinearLayout.VERTICAL);
        errorPanel.setGravity(Gravity.CENTER);
        errorPanel.setPadding(32, 32, 32, 32);

        TextView message = new TextView(this);
        message.setText("Jadwal belum dapat dibuka. Periksa koneksi internet, lalu coba lagi.");
        message.setTextColor(Color.DKGRAY);
        message.setTextSize(16);
        message.setGravity(Gravity.CENTER);

        Button retry = new Button(this);
        retry.setText("Coba Lagi");
        retry.setOnClickListener(v -> loadSchedule());

        errorPanel.addView(message);
        errorPanel.addView(retry);
        errorPanel.setVisibility(View.GONE);

        // Inisialisasi WebView
        webView = new WebView(this);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(false);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new PrintBridge(), "AndroidPrint");
        webView.setWebChromeClient(new WebChromeClient());

        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                String cookies = CookieManager.getInstance().getCookie(url);

                if (cookies != null) {
                    request.addRequestHeader("Cookie", cookies);
                }

                request.addRequestHeader("User-Agent", userAgent);
                request.setMimeType(mimeType != null ? mimeType : "application/pdf");

                String fileName = URLUtil.guessFileName(url, contentDisposition, mimeType);
                if (!fileName.toLowerCase().endsWith(".pdf")) {
                    fileName = fileName + ".pdf";
                }

                request.setTitle(fileName);
                request.setDescription("Mengunduh PDF Jadwal AN-NAWA");
                request.setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
                );
                request.setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS,
                    fileName
                );

                DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                if (manager != null) {
                    manager.enqueue(request);
                    Toast.makeText(MainActivity.this, "Unduhan PDF dimulai. Periksa folder Download.", Toast.LENGTH_LONG).show();
                }
            } catch (Exception e) {
                Log.e("ANNAWA_PDF", "Gagal mengunduh PDF", e);
                Toast.makeText(MainActivity.this, "Unduhan PDF gagal dimulai.", Toast.LENGTH_LONG).show();
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                return !"https".equalsIgnoreCase(scheme) && !"http".equalsIgnoreCase(scheme);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (errorPanel != null) errorPanel.setVisibility(View.GONE);
                if (webView != null) webView.setVisibility(View.VISIBLE);

                view.evaluateJavascript(
                    "(function() {" +
                    "  if (!window.__androidPrintInstalled) {" +
                    "    window.__androidPrintInstalled = true;" +
                    "    window.print = function() {" +
                    "      AndroidPrint.printPage();" +
                    "    };" +
                    "  }" +
                    "})();",
                    null
                );
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, android.webkit.WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request.isForMainFrame()) {
                    if (webView != null) webView.setVisibility(View.GONE);
                    if (errorPanel != null) errorPanel.setVisibility(View.VISIBLE);
                }
            }
        });

        root.addView(
            webView,
            new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        );

        root.addView(
            errorPanel,
            new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        );

        LinearLayout adContainer = new LinearLayout(this);
        adContainer.setOrientation(LinearLayout.VERTICAL);
        adContainer.setGravity(Gravity.CENTER);
        adContainer.setBackgroundColor(Color.WHITE);

        adStatus = new TextView(this);
        adStatus.setText("Menyiapkan iklan...");
        adStatus.setTextSize(10);
        adStatus.setTextColor(Color.GRAY);
        adStatus.setGravity(Gravity.CENTER);

        adContainer.addView(
            adStatus,
            new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        );

        adView = new AdView(this);
        adView.setAdSize(AdSize.BANNER);
        adView.setAdUnitId(BANNER_ID);

        adContainer.addView(
            adView,
            new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                AdSize.BANNER.getHeightInPixels(this)
            )
        );

        root.addView(
            adContainer,
            new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        );

        setContentView(root);

        adView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                Log.d("ANNAWA_ADS", "Iklan berhasil dimuat");
                runOnUiThread(() -> {
                    adStatus.setText("");
                    adStatus.setVisibility(View.GONE);
                });
            }

            @Override
            public void onAdFailedToLoad(LoadAdError error) {
                String detail = "Kode " + error.getCode() + ": " + error.getMessage();
                Log.e("ANNAWA_ADS", detail);
                runOnUiThread(() -> {
                    adStatus.setVisibility(View.VISIBLE);
                    adStatus.setText("Iklan belum tersedia (" + error.getCode() + ")");
                });
            }
        });

        MobileAds.initialize(this, initializationStatus -> {
            runOnUiThread(() -> {
                AdRequest adRequest = new AdRequest.Builder().build();
                adView.loadAd(adRequest);
            });
        });

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        }

        // Panggil loadSchedule dengan aman setelah semua komponen siap
        if (webView.getUrl() == null) {
            loadSchedule();
        }
    }

    
private class PrintBridge {

    @JavascriptInterface
    public void printPage() {
        runOnUiThread(() -> {
            if (webView == null || isFinishing()) {
                return;
            }

            try {
                String css =
                    "@media print {" +
                    "@page { size: A4; margin: 12mm !important; }" +
                    "html, body {" +
                    "  max-width: 100% !important;" +
                    "  box-sizing: border-box !important;" +
                    "}" +
                    "table {" +
                    "  max-width: 100% !important;" +
                    "  border-collapse: collapse !important;" +
                    "}" +
                    "th, td {" +
                    "  border: 1px solid #000 !important;" +
                    "  box-sizing: border-box !important;" +
                    "}" +
                    "}";

                String escapedCss = css
                    .replace("\\", "\\\\")
                    .replace("'", "\\'")
                    .replace("\n", "");

                String js =
                    "(function() {" +
                    " var s = document.getElementById('android-print-style');" +
                    " if (!s) {" +
                    "   s = document.createElement('style');" +
                    "   s.id = 'android-print-style';" +
                    "   document.head.appendChild(s);" +
                    " }" +
                    " s.textContent = '" + escapedCss + "';" +
                    " return 'ok';" +
                    "})();";

                webView.evaluateJavascript(js, result -> {
                    if (webView == null || isFinishing()) {
                        return;
                    }

                    try {
                        PrintManager printManager =
                            (PrintManager) getSystemService(
                                Context.PRINT_SERVICE
                            );

                        if (printManager == null) {
                            Toast.makeText(
                                MainActivity.this,
                                "Layanan cetak tidak tersedia",
                                Toast.LENGTH_LONG
                            ).show();
                            return;
                        }

                        String jobName =
                            "Jadwal_AnNawa_" + System.currentTimeMillis();

                        PrintDocumentAdapter printAdapter =
                            webView.createPrintDocumentAdapter(jobName);

                        PrintAttributes attributes =
                            new PrintAttributes.Builder()
                                .setMediaSize(
                                    PrintAttributes.MediaSize.ISO_A4
                                )
                                .setMinMargins(
                                    new PrintAttributes.Margins(
                                        400, 400, 400, 400
                                    )
                                )
                                .build();

                        printManager.print(
                            jobName,
                            printAdapter,
                            attributes
                        );

                    } catch (Exception e) {
                        Log.e(
                            "ANNAWA_PRINT",
                            "Gagal membuka cetak",
                            e
                        );

                        Toast.makeText(
                            MainActivity.this,
                            "Gagal membuka preview cetak",
                            Toast.LENGTH_LONG
                        ).show();
                    }
                });

            } catch (Exception e) {
                Log.e(
                    "ANNAWA_PRINT",
                    "Gagal menyiapkan CSS cetak",
                    e
                );

                Toast.makeText(
                    MainActivity.this,
                    "Gagal menyiapkan halaman cetak",
                    Toast.LENGTH_LONG
                ).show();
            }
        });
    }
}


    private void loadSchedule() {
        if (errorPanel != null && webView != null) {
            errorPanel.setVisibility(View.GONE);
            webView.setVisibility(View.VISIBLE);
            webView.loadUrl(APP_URL);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) {
            webView.saveState(outState);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (adView != null) {
            adView.destroy();
            adView = null;
        }

        if (webView != null) {
            webView.stopLoading();
            webView.removeJavascriptInterface("AndroidPrint");
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }

        super.onDestroy();
    }
}