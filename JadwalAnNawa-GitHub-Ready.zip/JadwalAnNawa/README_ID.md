# Jadwal An-Nawa — proyek APK Android

Proyek Android sederhana yang menampilkan Web App Google Apps Script Jadwal Pelajaran AN-NAWA dalam aplikasi Android menggunakan WebView.

## Fitur
- Nama aplikasi: Jadwal An-Nawa
- Ikon aplikasi sederhana bernuansa hijau
- Memuat URL Web App yang diberikan
- JavaScript, DOM storage, dan cookies diaktifkan untuk kompatibilitas Web App
- Tombol kembali Android mengikuti riwayat halaman
- Indikator proses muat dan panel coba lagi saat terjadi kesalahan jaringan

## Membuat APK dengan Android Studio

1. Di komputer, pasang Android Studio dari situs resmi Android Developers.
2. Ekstrak ZIP proyek ini.
3. Buka Android Studio → **Open** → pilih folder `JadwalAnNawa` yang berisi `settings.gradle`.
4. Izinkan Gradle sync dan instal Android SDK Platform 35 jika diminta. Gunakan JDK 17 atau versi yang didukung Android Gradle Plugin.
5. Sambungkan HP Android dengan USB debugging, atau gunakan emulator.
6. Untuk uji coba: tekan **Run**.
7. Untuk membuat berkas APK: menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
8. Setelah proses selesai, pilih **Locate**. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.
9. Salin APK ke HP, buka berkasnya, lalu izinkan pemasangan dari sumber tersebut bila Android meminta izin.

## Membuat APK lewat GitHub Actions

Proyek ini sudah dilengkapi workflow otomatis di `.github/workflows/build-apk.yml`. Setelah isi folder proyek diunggah ke repositori GitHub:

1. Buka repositori tersebut dan pilih tab **Actions**.
2. Pilih workflow **Build Jadwal An-Nawa APK**.
3. Tekan **Run workflow**, lalu tekan tombol hijau **Run workflow** jika diminta.
4. Tunggu hingga proses selesai dengan tanda centang hijau.
5. Buka hasil run tersebut, cari bagian **Artifacts**, lalu unduh `Jadwal-An-Nawa-debug-apk`.
6. Ekstrak ZIP artifact dan ambil `app-debug.apk`; pindahkan ke HP Android untuk dipasang.

Workflow juga berjalan otomatis saat ada perubahan yang di-push ke cabang `main` atau `master`. APK baru benar-benar tersedia setelah build GitHub Actions berhasil.

## Catatan penting
- Proyek sumber ini belum sama dengan APK yang sudah dikompilasi. APK harus dibangun dengan Android SDK/Gradle.
- APK ini memerlukan internet untuk memuat Web App. Data jadwal tetap bersumber dari Google Apps Script.
- Pastikan deployment Web App dapat diakses oleh akun/pengguna yang dituju. Jika Web App meminta login Google atau membatasi akses, perilaku login perlu diuji pada HP sasaran.
- APK debug cocok untuk uji coba dan distribusi terbatas. Untuk rilis resmi/Play Store, buat APK/AAB release dan tanda tangani dengan kunci yang aman.
- Package ID saat ini `id.annawa.jadwal`. Tetapkan ID final sebelum distribusi luas karena perubahan ID akan dianggap aplikasi berbeda.
